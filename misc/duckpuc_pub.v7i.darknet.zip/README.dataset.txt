# duckpuc_pub > 2022-09-23 2:39pm
https://universe.roboflow.com/object-detection/duckpuc_pub

Provided by Roboflow
License: CC BY 4.0

